

mkdir $1

wget -O ./$1/trained_model.zip $2

unzip ./$1/trained_model.zip -d ./$1