#!/bin/bash

bentoml serve service:ImageClassifyService --port $INFERENCE_SERVICE_PORT

