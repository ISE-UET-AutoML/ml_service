#!/bin/bash


rm -r ./dataset

rm -r ./model

rm trained_model.zip